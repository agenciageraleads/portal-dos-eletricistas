-- AlterTable
ALTER TABLE "users" ADD COLUMN     "bio" TEXT,
ADD COLUMN     "photo_url" TEXT,
ADD COLUMN     "skills" TEXT;
